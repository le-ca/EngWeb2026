# Projeto 2026 – Plataforma OAIS de Recursos Educativos

**UC:** Engenharia Web (2025/26) | 3º Ano 2º Semestre  
**Data de entrega:** 2026

---

## Autores

| | | |
|:---:|:---:|:---:|
| <img src="foto_goncalo.jpeg" width="120" height="120" style="object-fit:cover; border-radius:6px"> | <img src="foto_diogo.jpeg" width="120" height="120" style="object-fit:cover; border-radius:6px"> | <img src="foto_lourenco.jpeg" width="120" height="120" style="object-fit:cover; border-radius:6px"> |
| **Gonçalo Costa** | **Diogo Costa** | **Lourenço Martins** |
| A107381 | A107328 | A106849 |

---

## Resumo

Plataforma web para gestão e disponibilização de recursos educativos, desenvolvida no âmbito da UC de Engenharia Web seguindo o modelo OAIS.

A aplicação permite submeter recursos através de pacotes SIP em formato BagIt/ZIP, validar a sua integridade por checksum, guardar os ficheiros como AIP e disponibilizá-los para download como DIP. Os utilizadores podem pesquisar recursos, fazer posts, comentar e atribuir classificações por estrelas.

**Tecnologias:** Node.js · Express · MongoDB · Mongoose · Pug · Docker

---

## Execução

Para iniciar o projeto:

```bash
docker compose up --build -d
```

Para inicializar a base de dados (utilizadores de teste):

```bash
docker compose exec app npm run initdb
```

Para carregar os recursos de demonstração (15 SIPs de exemplo):

```bash
docker compose exec app npm run seeddb
```

A aplicação fica disponível em:

```
http://localhost:19001
```

Para parar:

```bash
docker compose down
```

Para voltar a correr sem reconstruir:

```bash
docker compose up -d
```

---

## Utilizadores de teste

| Username | Password | Nível |
|----------|----------|-------|
| admin | admin | Administrador |
| produtor | produtor | Produtor |
| consumidor | consumidor | Consumidor |
---

## Estrutura do projeto

```
controllers/    lógica principal da aplicação
models/         modelos da base de dados (Mongoose)
routes/         definição das rotas HTTP e API REST
views/          páginas Pug
public/         ficheiros estáticos (CSS)
middlewares/    autenticação e upload de ficheiros
scripts/        scripts de inicialização e seed da BD
samples/        exemplos de pacotes SIP em formato BagIt
storage/        armazenamento interno de AIPs e DIPs
```