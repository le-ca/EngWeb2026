var express = require('express')
var router = express.Router()
var Recursos = require('../controllers/recurso')
var auth = require('../middlewares/auth')
var upload = require('../middlewares/upload')

router.get('/', function(req, res, next) {
  var filtro = Recursos.filtroPesquisa(req.query, req.session.user)

  Recursos.list(filtro, req.session.user)
    .then(function(dados) { res.status(200).jsonp(dados) })
    .catch(function(erro) { next(erro) })
})

router.get('/top3', function(req, res, next) {
  Recursos.top3(req.session.user)
    .then(function(dados) { res.status(200).jsonp(dados) })
    .catch(function(erro) { next(erro) })
})

router.get('/:id', function(req, res, next) {
  Recursos.lookUp(req.params.id, req.session.user)
    .then(function(dados) {
      dados ? res.status(200).jsonp(dados) : res.status(404).jsonp({ erro: 'Recurso inexistente ou sem permissao.' })
    })
    .catch(function(erro) { next(erro) })
})

router.post('/', auth.ensureAuth, auth.isProdutor, upload.single('sip'), async function(req, res) {
  try {
    var r = await Recursos.insert(req.body, req.file, req.session.user)
    res.status(201).jsonp(r)
  } catch (e) {
    res.status(400).jsonp({ erro: e.message })
  }
})

router.put('/:id', auth.ensureAuth, auth.canManageResource, function(req, res, next) {
  Recursos.update(req.params.id, req.body, req.session.user)
    .then(function(dados) { res.status(200).jsonp(dados) })
    .catch(function(erro) { next(erro) })
})

router.delete('/:id', auth.ensureAuth, auth.canManageResource, function(req, res, next) {
  Recursos.remove(req.params.id)
    .then(function() { res.status(200).jsonp({ status: 'ok' }) })
    .catch(function(erro) { next(erro) })
})

module.exports = router
