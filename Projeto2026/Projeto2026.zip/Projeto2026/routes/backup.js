var express = require('express')
var router = express.Router()
var Backup = require('../controllers/backup')
var auth = require('../middlewares/auth')
var upload = require('../middlewares/uploadBackup')

router.get('/', auth.ensureAuth, auth.isAdmin, function(req, res) {
  res.render('backup', { title: 'Backup', resultado: null, erro: null })
})

router.get('/exportar', auth.ensureAuth, auth.isAdmin, async function(req, res, next) {
  try {
    var dados = await Backup.exportar()
    var nome = 'backup-recursos-oais-' + new Date().toISOString().substring(0, 10) + '.json'
    res.setHeader('Content-Disposition', 'attachment; filename="' + nome + '"')
    res.setHeader('Content-Type', 'application/json')
    res.send(JSON.stringify(dados, null, 2))
  } catch (e) {
    next(e)
  }
})

router.post('/importar', auth.ensureAuth, auth.isAdmin, upload.single('backup'), async function(req, res) {
  try {
    if (!req.file) throw new Error('Tem de enviar um ficheiro JSON.')
    var resultado = await Backup.importar(req.file.path)
    res.render('backup', { title: 'Backup', resultado: resultado, erro: null })
  } catch (e) {
    res.render('backup', { title: 'Backup', resultado: null, erro: e.message })
  }
})

module.exports = router
