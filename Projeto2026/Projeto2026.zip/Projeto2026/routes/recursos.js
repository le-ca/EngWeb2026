var express = require('express')
var router = express.Router()
var Recursos = require('../controllers/recurso')
var auth = require('../middlewares/auth')
var upload = require('../middlewares/upload')

router.get('/', function(req, res, next) {
  var filtro = Recursos.filtroPesquisa(req.query, req.session.user)

  Recursos.list(filtro, req.session.user)
    .then(function(dados) {
      res.render('recursos', {
        title: 'Recursos',
        recursos: dados,
        q: req.query.q,
        tipo: req.query.tipo,
        tag: req.query.tag,
        ano: req.query.ano
      })
    })
    .catch(function(erro) { next(erro) })
})

router.get('/novo', auth.ensureAuth, auth.isProdutor, function(req, res) {
  res.render('recursoForm', { title: 'Novo Recurso', recurso: {}, erro: null })
})

router.post('/novo', auth.ensureAuth, auth.isProdutor, upload.single('sip'), async function(req, res) {
  try {
    var r = await Recursos.insert(req.body, req.file, req.session.user)
    res.redirect('/recursos/' + r.id)
  } catch (e) {
    res.render('recursoForm', {
      title: 'Novo Recurso',
      recurso: req.body,
      erro: e.message
    })
  }
})

router.get('/:id', function(req, res, next) {
  Recursos.lookUp(req.params.id, req.session.user)
    .then(function(r) {
      if (!r) return res.status(404).render('error', { message: 'Recurso inexistente ou sem permissao.', error: {} })
      res.render('recurso', { title: r.titulo, recurso: r })
    })
    .catch(function(erro) { next(erro) })
})

router.get('/:id/edit', auth.ensureAuth, auth.canManageResource, function(req, res) {
  res.render('recursoForm', { title: 'Editar Recurso', recurso: req.recurso, erro: null })
})

router.post('/:id/edit', auth.ensureAuth, auth.canManageResource, function(req, res, next) {
  Recursos.update(req.params.id, req.body, req.session.user)
    .then(function() { res.redirect('/recursos/' + req.params.id) })
    .catch(function(erro) { next(erro) })
})

router.post('/:id/delete', auth.ensureAuth, auth.canManageResource, function(req, res, next) {
  Recursos.remove(req.params.id)
    .then(function() { res.redirect('/recursos') })
    .catch(function(erro) { next(erro) })
})

router.get('/:id/download', function(req, res, next) {
  Recursos.lookUp(req.params.id, req.session.user)
    .then(function(r) {
      if (!r) return res.status(404).render('error', { message: 'Recurso inexistente ou sem permissao.', error: {} })
      res.download(r.oais.dipPath, r.oais.sipOriginalName)
    })
    .catch(function(erro) { next(erro) })
})

router.post('/:id/posts', auth.ensureAuth, function(req, res, next) {
  Recursos.addPost(req.params.id, req.session.user, req.body.text)
    .then(function() { res.redirect('/recursos/' + req.params.id) })
    .catch(function(erro) { next(erro) })
})

router.post('/:id/posts/:postId/comments', auth.ensureAuth, function(req, res, next) {
  Recursos.addComment(req.params.id, req.params.postId, req.session.user, req.body.text)
    .then(function() { res.redirect('/recursos/' + req.params.id) })
    .catch(function(erro) { next(erro) })
})

router.post('/:id/rating', auth.ensureAuth, function(req, res, next) {
  Recursos.addRating(req.params.id, req.session.user, req.body.valor)
    .then(function() { res.redirect('/recursos/' + req.params.id) })
    .catch(function(erro) { next(erro) })
})

module.exports = router
