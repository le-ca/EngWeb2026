var bcrypt = require('bcryptjs')
var User = require('../models/user')

module.exports.list = function() {
  return User.find({}, { password: 0 }).sort({ nome: 1 }).exec()
}

module.exports.lookUp = function(id) {
  return User.findById(id, { password: 0 }).exec()
}

module.exports.lookUpUsername = function(username) {
  return User.findOne({ username: username }).exec()
}

module.exports.insert = async function(dados) {
  var hash = await bcrypt.hash(dados.password, 10)

  var u = new User({
    username: dados.username,
    nome: dados.nome,
    email: dados.email,
    password: hash,
    nivel: dados.nivel || 'consumidor',
    filiacao: dados.filiacao
  })

  return u.save()
}

module.exports.update = function(id, dados) {
  return User.findByIdAndUpdate(
    id,
    {
      $set: {
        username: dados.username,
        nome: dados.nome,
        email: dados.email,
        nivel: dados.nivel,
        ativo: dados.ativo,
        filiacao: dados.filiacao
      }
    },
    { new: true }
  ).exec()
}

module.exports.remove = function(id) {
  return User.findByIdAndDelete(id).exec()
}

module.exports.login = async function(username, password) {
  var user = await User.findOne({ username: username, ativo: true }).exec()
  if (!user) return null

  var ok = await bcrypt.compare(password, user.password)
  if (!ok) return null

  user.dataUltimoAcesso = new Date()
  await user.save()

  return {
    _id: user._id,
    username: user.username,
    nome: user.nome,
    email: user.email,
    nivel: user.nivel
  }
}
