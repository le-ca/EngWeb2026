var path = require('path')
var multer = require('multer')

var storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, path.join(__dirname, '..', 'storage', 'tmp'))
  },
  filename: function(req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname)
  }
})

function fileFilter(req, file, cb) {
  if (file.originalname.toLowerCase().endsWith('.zip')) cb(null, true)
  else cb(new Error('O SIP tem de ser um ficheiro ZIP.'))
}

module.exports = multer({ storage: storage, fileFilter: fileFilter })
