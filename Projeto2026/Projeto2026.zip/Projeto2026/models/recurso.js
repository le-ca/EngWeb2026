var mongoose = require('mongoose')

var CommentSchema = new mongoose.Schema({
  from: { type: String, required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
  text: { type: String, required: true },
  date: { type: Date, default: Date.now }
}, { _id: true })

var PostSchema = new mongoose.Schema({
  from: { type: String, required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
  text: { type: String, required: true },
  date: { type: Date, default: Date.now },
  comments: [CommentSchema]
}, { _id: true })

var RatingSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true },
  valor: { type: Number, min: 1, max: 5, required: true },
  date: { type: Date, default: Date.now }
}, { _id: false })

var FileSchema = new mongoose.Schema({
  path: String,
  checksum: String,
  algoritmo: String,
  tamanho: Number,
  mimetype: String
}, { _id: false })

var RecursoSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  titulo: { type: String, required: true },
  subtitulo: String,
  descricao: String,
  tipo: { type: String, required: true },
  formato: String,
  idioma: { type: String, default: 'pt' },
  autores: [String],
  palavrasChave: [String],
  unidadeCurricular: String,
  dataCriacao: String,
  dataSubmissao: { type: Date, default: Date.now },
  direitos: String,
  visibilidade: {
    type: String,
    enum: ['publico', 'privado'],
    default: 'publico'
  },
  produtor: { type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true },
  estado: {
    type: String,
    enum: ['submetido', 'validado', 'publicado', 'rejeitado'],
    default: 'submetido'
  },
  oais: {
    sipOriginalName: String,
    sipPath: String,
    aipPath: String,
    dipPath: String,
    bagPath: String,
    manifestPath: String,
    manifestAlgoritmo: String,
    validadoEm: Date,
    ficheiros: [FileSchema]
  },
  posts: [PostSchema],
  ratings: [RatingSchema]
}, { timestamps: true })

RecursoSchema.virtual('ranking').get(function() {
  if (!this.ratings || this.ratings.length === 0) return 0

  var soma = this.ratings.reduce(function(acc, r) {
    return acc + r.valor
  }, 0)

  return Math.round((soma / this.ratings.length) * 10) / 10
})

RecursoSchema.set('toJSON', { virtuals: true })
RecursoSchema.set('toObject', { virtuals: true })

module.exports = mongoose.model('recurso', RecursoSchema)
