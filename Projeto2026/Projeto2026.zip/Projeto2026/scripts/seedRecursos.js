var fs = require('fs')
var path = require('path')
var mongoose = require('mongoose')
var User = require('../models/user')
var Recurso = require('../models/recurso')
var ingest = require('../controllers/ingest')

var mongoDB = process.env.MONGO_URL || 'mongodb://127.0.0.1:27017/ewRecursos'

mongoose.connect(mongoDB)

var SAMPLES_DIR = path.join(__dirname, '..', 'samples')
var STORAGE_DIR = path.join(__dirname, '..', 'storage', 'aip')

function novoId() {
  return 'REI' + Date.now() + Math.floor(Math.random() * 1000)
}

async function seedRecursos() {
  // Encontra o produtor para associar os recursos de seed
  var produtor = await User.findOne({ nivel: 'produtor' }).exec()
  if (!produtor) {
    console.error('Utilizador produtor nao encontrado. Corre primeiro: npm run initdb')
    return
  }

  // Lista todos os ZIPs em samples/ (exceto o exemplo original)
  var zips = fs.readdirSync(SAMPLES_DIR).filter(function(f) {
    return f.endsWith('.zip') && f !== 'sip-exemplo.zip'
  })

  console.log('A ingerir ' + zips.length + ' SIPs...\n')

  for (var i = 0; i < zips.length; i++) {
    var zipFile = zips[i]
    var sipPath = path.join(SAMPLES_DIR, zipFile)

    // Verificar se ja existe um recurso com este SIP (evitar duplicados)
    var existe = await Recurso.findOne({ 'oais.sipOriginalName': zipFile }).exec()
    if (existe) {
      console.log('[skip]  ' + zipFile + ' (ja existe)')
      continue
    }

    try {
      var id = novoId()
      var aipBase = path.join(STORAGE_DIR, id)
      var bagDir = path.join(aipBase, 'bag')
      var sipDir = path.join(aipBase, 'original')

      fs.mkdirSync(bagDir, { recursive: true })
      fs.mkdirSync(sipDir, { recursive: true })

      // Copiar SIP para storage
      var sipDest = path.join(sipDir, zipFile)
      fs.copyFileSync(sipPath, sipDest)

      // Validar e extrair metadados BagIt
      var validacao = await ingest.validarBagIt(sipDest, bagDir)
      var info = validacao.bagInfo

      var r = new Recurso({
        id: id,
        titulo: info['Title'] || zipFile,
        descricao: info['Description'] || '',
        tipo: info['Type'] || 'recurso educativo',
        formato: 'zip/bagit',
        idioma: 'pt',
        autores: info['Authors'] ? info['Authors'].split(',').map(function(a) { return a.trim() }) : [],
        palavrasChave: info['Keywords'] ? info['Keywords'].split(',').map(function(k) { return k.trim() }) : [],
        unidadeCurricular: info['UC'] || '',
        dataCriacao: info['Date'] || '',
        direitos: info['Rights'] || 'Uso academico',
        visibilidade: 'publico',
        produtor: produtor._id,
        estado: 'publicado',
        oais: {
          sipOriginalName: zipFile,
          sipPath: sipDest,
          aipPath: aipBase,
          dipPath: sipDest,
          bagPath: bagDir,
          manifestPath: validacao.manifestPath,
          manifestAlgoritmo: validacao.manifestAlgoritmo,
          validadoEm: new Date(),
          ficheiros: validacao.ficheiros
        }
      })

      await r.save()
      console.log('[ok]    ' + zipFile + ' -> ' + id)
    } catch (e) {
      console.error('[erro]  ' + zipFile + ': ' + e.message)
    }
  }

  console.log('\nSeed concluido.')
}

mongoose.connection.on('open', async function() {
  try {
    await seedRecursos()
  } catch (e) {
    console.error(e)
  } finally {
    mongoose.connection.close()
  }
})
