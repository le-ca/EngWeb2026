var mongoose = require('mongoose')
var bcrypt = require('bcryptjs')
var User = require('../models/user')
var Recurso = require('../models/recurso')

var mongoDB = process.env.MONGO_URL || 'mongodb://127.0.0.1:27017/ewRecursos'

mongoose.connect(mongoDB)

async function criaUser(username, nome, email, nivel) {
  var existe = await User.findOne({ username: username }).exec()
  if (existe) return

  var hash = await bcrypt.hash(username, 10)
  await User.create({
    username: username,
    nome: nome,
    email: email,
    password: hash,
    nivel: nivel,
    filiacao: 'DI/UMinho'
  })

  console.log('Utilizador criado: ' + username + '/' + username)
}

mongoose.connection.on('open', async function() {
  try {
    await mongoose.connection.db.createCollection('users').catch(function() {})
    await mongoose.connection.db.createCollection('recursos').catch(function() {})

    await User.collection.createIndex({ username: 1 }, { unique: true })
    await User.collection.createIndex({ email: 1 }, { unique: true })
    await Recurso.collection.createIndex({ id: 1 }, { unique: true })
    await Recurso.collection.createIndex({ titulo: 'text', descricao: 'text', palavrasChave: 'text' })
    await Recurso.collection.createIndex({ tipo: 1 })
    await Recurso.collection.createIndex({ visibilidade: 1, estado: 1 })

    await criaUser('admin', 'Administrador', 'admin@ew.local', 'administrador')
    await criaUser('produtor', 'Produtor Exemplo', 'produtor@ew.local', 'produtor')
    await criaUser('consumidor', 'Consumidor Exemplo', 'consumidor@ew.local', 'consumidor')

    console.log('Base de dados inicializada com sucesso.')
  } catch (e) {
    console.error(e)
  } finally {
    mongoose.connection.close()
  }
})
